const _0x9002c4 = (function () {
    let _0x6c4720 = true
    return function (_0x570bae, _0x4b56ef) {
        const _0x5897de = _0x6c4720
            ? function () {
                if (_0x4b56ef) {
                    const _0x425a7f = _0x4b56ef.apply(_0x570bae, arguments)
                    return (_0x4b56ef = null), _0x425a7f
                }
            }
            : function () { }
        return (_0x6c4720 = false), _0x5897de
    }
})(),
    _0x161b97 = _0x9002c4(this, function () {
        return _0x161b97
            .toString()
            .search('(((.+)+)+)+$')
            .toString()
            .constructor(_0x161b97)
            .search('(((.+)+)+)+$')
    })
// _0x161b97()
const Discord = require('discord.js'),
    fs = require('fs'),
    yaml = require('js-yaml'),
    config = yaml.load(fs.readFileSync('./config.yml', 'utf8')),
    colors = require('ansi-colors'),
    packageFile = require('./package.json')
async function handleInvalidLicense(_0x1cfb83) {
    const _0x5d8793 =
        '\n\n[' +
        new Date().toLocaleString() +
        '] [LIC] res.data ' +
        JSON.stringify(_0x1cfb83) +
        '\n'
    await fs.appendFileSync('./logs.txt', _0x5d8793, (_0x440832) => {
        if (_0x440832) {
            console.log(_0x440832)
        }
    })
    await console.log(
        '\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015'
    )
    await console.log(
        '\x1B[31m%s\x1B[0m',
        'Your license key is invalid! (Guild limit of 3 reached)'
    )
    await console.log(
        '\x1B[31m%s\x1B[0m',
        'Create a ticket in our discord server for help.'
    )
    await console.log(
        '\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015'
    )
}
async function handleRateLimitExceeded(_0x4e94f1) {
    const _0x2d8baf =
        '\n\n[' +
        new Date().toLocaleString() +
        '] [LIC] res.data ' +
        JSON.stringify(_0x4e94f1) +
        '\n'
    return (
        await fs.appendFileSync('./logs.txt', _0x2d8baf, (_0x420956) => {
            if (_0x420956) {
                console.log(_0x420956)
            }
        }),
        await console.log(
            '\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015'
        ),
        await console.log(
            '\x1B[31m%s\x1B[0m',
            'Rate limit exeeded! Try starting the bot again in 3 minutes.'
        ),
        await console.log(
            '\x1B[31m%s\x1B[0m',
            'Create a ticket in our discord server for help.'
        ),
        await console.log(
            '\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015'
        )
        // process.exit(1)
    )
}
async function handleInvalidLicenseKey(_0x48309b) {
    const _0x5f19af =
        '\n\n[' +
        new Date().toLocaleString() +
        '] [LIC] res.data ' +
        JSON.stringify(_0x48309b) +
        '\n'
    return (
        await fs.appendFileSync('./logs.txt', _0x5f19af, (_0x581d50) => {
            if (_0x581d50) {
                console.log(_0x581d50)
            }
        }),
        await console.log(
            '\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015'
        ),
        await console.log('\x1B[31m%s\x1B[0m', 'Your license key is invalid!'),
        await console.log(
            '\x1B[31m%s\x1B[0m',
            'Create a ticket in our discord server to get one. discord.gg/UnHAAGH'
        ),
        await console.log(
            '\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015'
        )
        // process.exit(1)
    )
}
async function handleInvalidLicenseStatus(_0x189ed6) {
    const _0x3a5851 =
        '\n\n[' +
        new Date().toLocaleString() +
        '] [LIC] res.data.status_overview !==: ' +
        _0x189ed6.status_overview
    return (
        await fs.appendFileSync('./logs.txt', _0x3a5851, (_0xd155c0) => {
            if (_0xd155c0) {
                console.log(_0xd155c0)
            }
        }),
        await console.log(
            '\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015'
        ),
        await console.log('\x1B[31m%s\x1B[0m', 'Your license key is invalid!'),
        await console.log(
            '\x1B[31m%s\x1B[0m',
            'Create a ticket in our discord server to get one. discord.gg/UnHAAGH'
        ),
        await console.log(
            '\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015\u2015'
        )
        // process.exit(1)
    )
}
module.exports = {
    handleInvalidLicenseKey: handleInvalidLicenseKey,
    handleInvalidLicenseStatus: handleInvalidLicenseStatus,
    handleRateLimitExceeded: handleRateLimitExceeded,
    handleInvalidLicense: handleInvalidLicense,
}
