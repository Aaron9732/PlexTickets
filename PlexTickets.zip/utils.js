const _0x3fba22 = (function () {
    let _0x297e6e = !![];
    return function (_0x372b4b, _0x457505) {
        const _0x480ec2 = _0x297e6e
            ? function () {
                if (_0x457505) {
                    const _0x543c04 = _0x457505["apply"](_0x372b4b, arguments);
                    return (_0x457505 = null), _0x543c04;
                }
            }
            : function () { };
        return (_0x297e6e = ![]), _0x480ec2;
    };
})(),
    _0xc58ff9 = _0x3fba22(this, function () {
        return _0xc58ff9["toString"]()
        ["search"]("(((.+)+)+)+$")
        ["toString"]()
        ["constructor"](_0xc58ff9)
        ["search"]("(((.+)+)+)+$");
    });
// _0xc58ff9();
const {
    Collection,
    Client,
    Discord,
    Intents,
    AttachmentBuilder,
    ActionRowBuilder,
    EmbedBuilder,
    ButtonBuilder,
} = require("discord.js"),
    fs = require("fs"),
    yaml = require("js-yaml"),
    fetch = require("node-fetch"),
    config = yaml["load"](fs["readFileSync"]("./config.yml", "utf8")),
    client = require("./index.js"),
    color = require("ansi-colors"),
    axios = require("axios"),
    glob = require("glob");
let discordTranscripts;
if (config["TicketTranscriptSettings"]["TranscriptType"] === "HTML")
    discordTranscripts = require("discord-html-transcripts");
(client["commands"] = new Collection()),
    (client["slashCommands"] = new Collection());
const Enmap = require("enmap");
(client["tickets"] = new Enmap({
    name: "tickets",
    autoFetch: !![],
    fetchAll: ![],
})),
    (client["globalStats"] = new Enmap({
        name: "globalStats",
        autoFetch: !![],
        fetchAll: ![],
    })),
    (client["userStats"] = new Enmap({
        name: "userStats",
        autoFetch: !![],
        fetchAll: ![],
    })),
    (client["suggestions"] = new Enmap({
        name: "suggestions",
        autoFetch: !![],
        fetchAll: ![],
    })),
    (client["suggestionUsers"] = new Enmap({
        name: "suggestionUsers",
        autoFetch: !![],
        fetchAll: ![],
    })),
    (client["blacklistedUsers"] = new Enmap({
        name: "blacklistedUsers",
        autoFetch: !![],
        fetchAll: ![],
    })),
    (client["reviews"] = new Enmap({
        name: "reviews",
        autoFetch: !![],
        fetchAll: ![],
    })),
    (client["reviewsData"] = new Enmap({
        name: "reviewsData",
        autoFetch: !![],
        fetchAll: ![],
    })),
    (client["ticketPanel"] = new Enmap({
        name: "ticketPanel",
        autoFetch: !![],
        fetchAll: ![],
    })),
    (client["stripeInvoices"] = new Enmap({
        name: "stripeInvoices",
        autoFetch: !![],
        fetchAll: !![],
    })),
    (client["paypalInvoices"] = new Enmap({
        name: "paypalInvoices",
        autoFetch: !![],
        fetchAll: !![],
    })),
    (client["cooldowns"] = new Collection());
const StripeMain = require("stripe"),
    stripe = StripeMain(config["StripeSettings"]["StripeSecretKey"]);
client["stripe"] = stripe;
const paypal = require("paypal-rest-sdk");
paypal["configure"]({
    mode: "live",
    client_id: config["PayPalSettings"]["PayPalClientID"],
    client_secret: config["PayPalSettings"]["PayPalSecretKey"],
}),
    (client["paypal"] = paypal);
const { REST } = require("@discordjs/rest"),
    { Routes } = require("discord-api-types/v10");
if (config["GuildID"]) {
    const slashCommands = [],
        commandFolders = fs["readdirSync"]("./slashCommands");
    for (const folder of commandFolders) {
        const commandFiles = fs["readdirSync"]("./slashCommands/" + folder)[
            "filter"
        ]((_0x57479c) => _0x57479c["endsWith"](".js"));
        for (const file of commandFiles) {
            const command = require("./slashCommands/" + folder + "/" + file);
            command["enabled"] &&
                (slashCommands["push"](command["data"]["toJSON"]()),
                    console["log"]("[SLASH\x20COMMAND]\x20" + file + "\x20loaded!"),
                    client["slashCommands"]["set"](command["data"]["name"], command));
        }
    }
    glob("./addons/**/*.js", function (_0x1a8555, _0x30e559) {
        if (_0x1a8555) return console["error"](_0x1a8555);
        const _0x5f338f = [];
        _0x30e559["forEach"]((_0x145edd) => {
            if (_0x145edd["endsWith"](".js")) {
                const _0x4e8286 = _0x145edd["match"](/\/addons\/([^/]+)/)[0x1];
                !_0x5f338f["includes"](_0x4e8286) &&
                    (_0x5f338f["push"](_0x4e8286),
                        console["log"](
                            "" + color["green"]("[ADDON]\x20" + _0x4e8286 + "\x20loaded!")
                        ));
                if (_0x145edd["search"]("cmd_") >= 0x0) {
                    let _0x469b35 = require(_0x145edd);
                    slashCommands["push"](_0x469b35["data"]["toJSON"]()),
                        client["slashCommands"]["set"](
                            _0x469b35["data"]["name"],
                            _0x469b35
                        );
                } else {
                    let _0x3bb0dd = require(_0x145edd);
                    _0x3bb0dd["run"](client);
                }
            }
        });
    }),
        client["on"]("ready", async () => {
            const _0x3c0e6f = new REST({ version: "10" })["setToken"](
                config["Token"]
            );
            (async () => {
                try {
                    await _0x3c0e6f["put"](
                        Routes["applicationGuildCommands"](
                            client["user"]["id"],
                            config["GuildID"]
                        ),
                        { body: slashCommands }
                    );
                } catch (_0x28f247) {
                    if (_0x28f247) {
                        let _0x5d6074 =
                            "\x0a\x0a[" +
                            new Date()["toLocaleString"]() +
                            "]\x20[ERROR]\x20" +
                            _0x28f247["stack"];
                        await fs["appendFile"]("./logs.txt", _0x5d6074, (_0x299cc8) => {
                            if (_0x299cc8) console["log"](_0x299cc8);
                        }),
                            await console["log"](
                                "\x1b[31m%s\x1b[0m",
                                "[ERROR]\x20Slash\x20commands\x20are\x20unavailable\x20because\x20application.commands\x20scope\x20wasn\x27t\x20selected\x20when\x20inviting\x20the\x20bot.\x20Please\x20use\x20the\x20link\x20below\x20to\x20re-invite\x20your\x20bot."
                            ),
                            await console["log"](
                                "\x1b[31m%s\x1b[0m",
                                "https://discord.com/api/oauth2/authorize?client_id=" +
                                client["user"]["id"] +
                                "&permissions=8&scope=bot%20applications.commands"
                            );
                    }
                }
            })();
        });
}
const {
    handleInvalidLicense,
    handleRateLimitExceeded,
    handleInvalidLicenseStatus,
    handleInvalidLicenseKey,
} = require("./licenseHandlers.js");
(exports["validateLicense"] = async function (_0x3bc8c0) {
    const _0x821261 = "http://api.plexdevelopment.net/api/client",
        _0x48ff72 = config["LicenseKey"],
        _0x40d8c8 = "PlexTickets",
        _0x50b7ce = "FMo07f0yWFB37IAhrF",
        _0x2e1946 = config["GuildID"],
        _0x4d9796 = await axios["post"](
            _0x821261,
            { licensekey: _0x48ff72, product: _0x40d8c8, hwid: _0x2e1946 },
            { headers: { Authorization: _0x50b7ce } }
        );
    if (_0x4d9796["data"]["status_msg"] === "MAX_HWID_CAP")
        return await handleInvalidLicense(_0x4d9796["data"])
    if (_0x4d9796["data"]["status_msg"] === "RATE_LIMIT_EXCEEDED")
        return (
            await handleRateLimitExceeded(_0x4d9796["data"])
        );
    if (!_0x4d9796["data"]["status_code"] || !_0x4d9796["data"]["status_id"])
        return (
            await handleInvalidLicenseKey(_0x4d9796["data"])
        );
    if (_0x4d9796["data"]["status_overview"] !== "success")
        return (
            await handleInvalidLicenseStatus(_0x4d9796["data"])
        );
}),
    fs["readdir"]("./events/", (_0x40126f, _0x338114) => {
        if (_0x40126f) return console["error"];
        _0x338114["forEach"](async (_0x20d888) => {
            if (!_0x20d888["endsWith"](".js")) return;
            console["log"]("[EVENT]\x20" + _0x20d888 + "\x20loaded!");
            const _0x423aca = require("./events/" + _0x20d888);
            let _0x3721fb = _0x20d888["split"](".")[0x0];
            client["on"](_0x3721fb, _0x423aca["bind"](null, client));
        });
    }),
    client["on"]("interactionCreate", async (_0x249a61) => {
        if (!_0x249a61["isChatInputCommand"]()) return;
        const _0x4c5227 = client["slashCommands"]["get"](_0x249a61["commandName"]);
        if (!_0x4c5227) return;
        let _0x5159f7 =
            "\x0a\x0a[" +
            new Date()["toLocaleString"]() +
            "]\x20[SLASH\x20COMMAND]\x20Command:\x20" +
            _0x249a61["commandName"] +
            ",\x20User:\x20" +
            _0x249a61["user"]["username"];
        fs["appendFile"]("./logs.txt", _0x5159f7, (_0x2f14fd) => {
            if (_0x2f14fd) console["log"](_0x2f14fd);
        });
        if (config["LogCommands"])
            console["log"](
                "" +
                color["yellow"](
                    "[SLASH\x20COMMAND]\x20" +
                    color["cyan"]("" + _0x249a61["user"]["username"]) +
                    "\x20used\x20" +
                    color["cyan"]("/" + _0x249a61["commandName"])
                )
            );
        try {
            await _0x4c5227["execute"](_0x249a61, client);
        } catch (_0x2fc1a4) {
            if (_0x2fc1a4) console["error"](_0x2fc1a4);
        }
    }),
    (exports["averageRating"] = function (_0x255b18) {
        const _0x1ba476 = _0x255b18["reviews"]["get"](config["GuildID"], "ratings"),
            _0x5970c9 = _0x1ba476["flatMap"]((_0x3722aa) =>
                _0x3722aa["map"]((_0x4c6f57) => _0x4c6f57["rating"])
            ),
            _0x24b7db = _0x5970c9["length"]
                ? (_0x5970c9["reduce"](
                    (_0x254499, _0x3ca6b8) => _0x254499 + _0x3ca6b8
                ) / _0x5970c9["length"])["toFixed"](0x1)
                : "0.0";
        return _0x24b7db;
    }),
    (exports["checkConfig"] = function (_0x357f84) {
        let _0x38de2c = [],
            _0x59c6d2 = _0x357f84["guilds"]["cache"]["get"](config["GuildID"]);
        var _0x4f1f24 = /^#([0-9a-f]{3}){1,2}$/i;
        _0x4f1f24["test"](config["EmbedColors"]) === ![] &&
            (console["log"](
                "\x1b[31m%s\x1b[0m",
                "[WARNING]\x20EmbedColors\x20is\x20not\x20a\x20valid\x20HEX\x20Color!"
            ),
                _0x38de2c["push"](
                    "EmbedColors\x20is\x20not\x20a\x20valid\x20HEX\x20Color!"
                ));
        !_0x59c6d2["channels"]["cache"]["get"](
            config["TicketSettings"]["LogsChannelID"]
        ) &&
            (console["log"](
                "\x1b[31m%s\x1b[0m",
                "[WARNING]\x20TicketSettings.LogsChannelID\x20is\x20not\x20a\x20valid\x20channel!"
            ),
                _0x38de2c["push"](
                    "TicketSettings.LogsChannelID\x20is\x20not\x20a\x20valid\x20channel!"
                ));
        config["ArchiveTickets"]["Enabled"] &&
            !_0x59c6d2["channels"]["cache"]["get"](
                config["ArchiveTickets"]["TranscriptChannelID"]
            ) &&
            (console["log"](
                "\x1b[31m%s\x1b[0m",
                "[WARNING]\x20ArchiveTickets.TranscriptChannelID\x20is\x20not\x20a\x20valid\x20channel!"
            ),
                _0x38de2c["push"](
                    "ArchiveTickets.TranscriptChannelID\x20is\x20not\x20a\x20valid\x20channel!"
                ));
        for (let _0x181050 = 0x1; _0x181050 <= 0x8; _0x181050++) {
            const _0x121742 = config["TicketButton" + _0x181050];
            !_0x121742 &&
                (console["log"](
                    "\x1b[31m%s\x1b[0m",
                    "[ERROR]\x20You\x20have\x20removed\x20TicketButton" +
                    _0x181050 +
                    "\x20from\x20the\x20config\x20which\x20means\x20that\x20the\x20bot\x20won\x27t\x20function\x20properly,\x20You\x20can\x20set\x20Enabled\x20to\x20false\x20if\x20you\x20want\x20to\x20disable\x20it\x20instead."
                ),
                    _0x38de2c["push"](
                        "TicketButton" + _0x181050 + "\x20removed\x20from\x20the\x20config!"
                    ),
                    process["exit"]());
        }
        !["Blurple", "Gray", "Green", "Red"]["includes"](
            config["TicketButton1"]["ButtonColor"]
        ) &&
            (console["log"](
                "\x1b[31m%s\x1b[0m",
                "[WARNING]\x20TicketButton1.ButtonColor\x20is\x20not\x20a\x20valid\x20color!\x20Valid\x20colors:\x20Blurple,\x20Gray,\x20Green,\x20Red\x20(CASE\x20SENSITIVE)"
            ),
                _0x38de2c["push"](
                    "TicketButton1.ButtonColor\x20is\x20not\x20a\x20valid\x20color!"
                ));
        !["Blurple", "Gray", "Green", "Red"]["includes"](
            config["TicketButton2"]["ButtonColor"]
        ) &&
            config["TicketButton2"]["Enabled"] &&
            (console["log"](
                "\x1b[31m%s\x1b[0m",
                "[WARNING]\x20TicketButton2.ButtonColor\x20is\x20not\x20a\x20valid\x20color!\x20Valid\x20colors:\x20Blurple,\x20Gray,\x20Green,\x20Red\x20(CASE\x20SENSITIVE)"
            ),
                _0x38de2c["push"](
                    "TicketButton2.ButtonColor\x20is\x20not\x20a\x20valid\x20color!"
                ));
        !["Blurple", "Gray", "Green", "Red"]["includes"](
            config["TicketButton3"]["ButtonColor"]
        ) &&
            config["TicketButton3"]["Enabled"] &&
            (console["log"](
                "\x1b[31m%s\x1b[0m",
                "[WARNING]\x20TicketButton3.ButtonColor\x20is\x20not\x20a\x20valid\x20color!\x20Valid\x20colors:\x20Blurple,\x20Gray,\x20Green,\x20Red\x20(CASE\x20SENSITIVE)"
            ),
                _0x38de2c["push"](
                    "TicketButton3.ButtonColor\x20is\x20not\x20a\x20valid\x20color!"
                ));
        !["Blurple", "Gray", "Green", "Red"]["includes"](
            config["TicketButton4"]["ButtonColor"]
        ) &&
            config["TicketButton4"]["Enabled"] &&
            (console["log"](
                "\x1b[31m%s\x1b[0m",
                "[WARNING]\x20TicketButton4.ButtonColor\x20is\x20not\x20a\x20valid\x20color!\x20Valid\x20colors:\x20Blurple,\x20Gray,\x20Green,\x20Red\x20(CASE\x20SENSITIVE)"
            ),
                _0x38de2c["push"](
                    "TicketButton4.ButtonColor\x20is\x20not\x20a\x20valid\x20color!"
                ));
        !["Blurple", "Gray", "Green", "Red"]["includes"](
            config["TicketButton5"]["ButtonColor"]
        ) &&
            config["TicketButton5"]["Enabled"] &&
            (console["log"](
                "\x1b[31m%s\x1b[0m",
                "[WARNING]\x20TicketButton5.ButtonColor\x20is\x20not\x20a\x20valid\x20color!\x20Valid\x20colors:\x20Blurple,\x20Gray,\x20Green,\x20Red\x20(CASE\x20SENSITIVE)"
            ),
                _0x38de2c["push"](
                    "TicketButton5.ButtonColor\x20is\x20not\x20a\x20valid\x20color!"
                ));
        !["Blurple", "Gray", "Green", "Red"]["includes"](
            config["SuggestionUpvote"]["ButtonColor"]
        ) &&
            config["SuggestionSettings"]["Enabled"] &&
            (console["log"](
                "\x1b[31m%s\x1b[0m",
                "[WARNING]\x20SuggestionUpvote.ButtonColor\x20is\x20not\x20a\x20valid\x20color!\x20Valid\x20colors:\x20Blurple,\x20Gray,\x20Green,\x20Red\x20(CASE\x20SENSITIVE)"
            ),
                _0x38de2c["push"](
                    "SuggestionUpvote.ButtonColor\x20is\x20not\x20a\x20valid\x20color!"
                ));
        !["Blurple", "Gray", "Green", "Red"]["includes"](
            config["SuggestionDownvote"]["ButtonColor"]
        ) &&
            config["SuggestionSettings"]["Enabled"] &&
            (console["log"](
                "\x1b[31m%s\x1b[0m",
                "[WARNING]\x20SuggestionDownvote.ButtonColor\x20is\x20not\x20a\x20valid\x20color!\x20Valid\x20colors:\x20Blurple,\x20Gray,\x20Green,\x20Red\x20(CASE\x20SENSITIVE)"
            ),
                _0x38de2c["push"](
                    "SuggestionDownvote.ButtonColor\x20is\x20not\x20a\x20valid\x20color!"
                ));
        !["Blurple", "Gray", "Green", "Red"]["includes"](
            config["SuggestionResetvote"]["ButtonColor"]
        ) &&
            config["SuggestionSettings"]["Enabled"] &&
            (console["log"](
                "\x1b[31m%s\x1b[0m",
                "[WARNING]\x20SuggestionResetvote.ButtonColor\x20is\x20not\x20a\x20valid\x20color!\x20Valid\x20colors:\x20Blurple,\x20Gray,\x20Green,\x20Red\x20(CASE\x20SENSITIVE)"
            ),
                _0x38de2c["push"](
                    "SuggestionResetvote.ButtonColor\x20is\x20not\x20a\x20valid\x20color!"
                ));
        !["Blurple", "Gray", "Green", "Red"]["includes"](
            config["SuggestionAccept"]["ButtonColor"]
        ) &&
            config["SuggestionSettings"]["Enabled"] &&
            (console["log"](
                "\x1b[31m%s\x1b[0m",
                "[WARNING]\x20SuggestionAccept.ButtonColor\x20is\x20not\x20a\x20valid\x20color!\x20Valid\x20colors:\x20Blurple,\x20Gray,\x20Green,\x20Red\x20(CASE\x20SENSITIVE)"
            ),
                _0x38de2c["push"](
                    "SuggestionAccept.ButtonColor\x20is\x20not\x20a\x20valid\x20color!"
                ));
        !["Blurple", "Gray", "Green", "Red"]["includes"](
            config["SuggestionDeny"]["ButtonColor"]
        ) &&
            config["SuggestionSettings"]["Enabled"] &&
            (console["log"](
                "\x1b[31m%s\x1b[0m",
                "[WARNING]\x20SuggestionDeny.ButtonColor\x20is\x20not\x20a\x20valid\x20color!\x20Valid\x20colors:\x20Blurple,\x20Gray,\x20Green,\x20Red\x20(CASE\x20SENSITIVE)"
            ),
                _0x38de2c["push"](
                    "SuggestionDeny.ButtonColor\x20is\x20not\x20a\x20valid\x20color!"
                ));
        for (let _0x5a42fa = 0x1; _0x5a42fa <= 0x8; _0x5a42fa++) {
            const _0x4c2eca = config["TicketButton" + _0x5a42fa];
            if (_0x5a42fa !== 0x1 && !_0x4c2eca["Enabled"]) continue;
            _0x59c6d2["channels"]["cache"]["get"](_0x4c2eca["TicketCategoryID"])?.[
                "type"
            ] !== 0x4 &&
                (console["log"](
                    "\x1b[31m%s\x1b[0m",
                    "[WARNING]\x20TicketButton" +
                    _0x5a42fa +
                    ".TicketCategoryID\x20is\x20not\x20a\x20valid\x20category!"
                ),
                    _0x38de2c["push"](
                        "TicketButton" +
                        _0x5a42fa +
                        ".TicketCategoryID\x20is\x20not\x20a\x20valid\x20category!"
                    ));
        }
        for (let _0x36f1ba = 0x1; _0x36f1ba <= 0x8; _0x36f1ba++) {
            const _0x3e8fab = config["TicketButton" + _0x36f1ba];
            if (_0x36f1ba !== 0x1 && !_0x3e8fab["Enabled"]) continue;
            config["TicketSettings"]["ArchiveTickets"] &&
                _0x59c6d2["channels"]["cache"]["get"](_0x3e8fab["ClosedCategoryID"])?.[
                "type"
                ] !== 0x4 &&
                (console["log"](
                    "\x1b[31m%s\x1b[0m",
                    "[WARNING]\x20TicketButton" +
                    _0x36f1ba +
                    ".ClosedCategoryID\x20is\x20not\x20a\x20valid\x20category!"
                ),
                    _0x38de2c["push"](
                        "TicketButton" +
                        _0x36f1ba +
                        ".ClosedCategoryID\x20is\x20not\x20a\x20valid\x20category!"
                    ));
        }
        for (let _0x3683c8 = 0x1; _0x3683c8 <= 0x8; _0x3683c8++) {
            const _0x539c15 = config["TicketButton" + _0x3683c8];
            if (_0x3683c8 !== 0x1 && !_0x539c15["Enabled"]) continue;
            _0x539c15["Description"]["length"] > 0x64 &&
                (console["log"](
                    "\x1b[31m%s\x1b[0m",
                    "[WARNING]\x20TicketButton" +
                    _0x3683c8 +
                    ".Description\x20can\x27t\x20be\x20longer\x20than\x20100\x20characters!"
                ),
                    _0x38de2c["push"](
                        "TicketButton" +
                        _0x3683c8 +
                        ".Description\x20can\x27t\x20be\x20longer\x20than\x20100\x20characters!"
                    ));
        }
        for (let _0x4dd27a = 0x1; _0x4dd27a <= 0x8; _0x4dd27a++) {
            const _0x4783fb = config["TicketButton" + _0x4dd27a];
            if (_0x4dd27a !== 0x1 && !_0x4783fb["Enabled"]) continue;
            _0x4783fb["SupportRoles"]["forEach"]((_0x38c93b) => {
                const _0x29dc6c = _0x59c6d2["roles"]["cache"]["get"](_0x38c93b);
                !_0x29dc6c &&
                    (console["log"](
                        "\x1b[31m%s\x1b[0m",
                        "[WARNING]\x20TicketButton" +
                        _0x4dd27a +
                        ".SupportRoles\x20is\x20not\x20a\x20valid\x20role!\x20(" +
                        _0x38c93b +
                        ")"
                    ),
                        _0x38de2c["push"](
                            "TicketButton" +
                            _0x4dd27a +
                            ".SupportRoles\x20is\x20not\x20a\x20valid\x20role!"
                        ));
            });
        }
        const _0x1e1cc8 = require("emoji-regex"),
            _0xa82c1c = /<a?:[a-zA-Z0-9_]+:(\d+)>/;
        for (let _0x840252 = 0x1; _0x840252 <= 0x8; _0x840252++) {
            const _0x3ae9b9 = config["TicketButton" + _0x840252];
            if (_0x840252 !== 0x1 && !_0x3ae9b9["Enabled"]) continue;
            if (_0x3ae9b9["ButtonEmoji"]) {
                const _0x28685c = _0x1e1cc8(),
                    _0x18321f = _0x28685c["exec"](_0x3ae9b9["ButtonEmoji"]),
                    _0x10cfa1 = _0x3ae9b9["ButtonEmoji"]["match"](_0xa82c1c);
                !_0x18321f &&
                    !_0x10cfa1 &&
                    (console["log"](
                        "\x1b[31m%s\x1b[0m",
                        "[WARNING]\x20TicketButton" +
                        _0x840252 +
                        ".ButtonEmoji\x20contains\x20an\x20invalid\x20emoji!\x20(" +
                        _0x3ae9b9["ButtonEmoji"] +
                        ")"
                    ),
                        _0x38de2c["push"](
                            "TicketButton" +
                            _0x840252 +
                            ".ButtonEmoji\x20contains\x20an\x20invalid\x20emoji!"
                        ));
            }
        }
        for (let _0x4ef60e = 0x1; _0x4ef60e <= 0x8; _0x4ef60e++) {
            const _0x4abc27 = config["TicketButton" + _0x4ef60e];
            if (_0x4ef60e !== 0x1 && !_0x4abc27["Enabled"]) continue;
            Array["isArray"](_0x4abc27["Questions"]) &&
                _0x4abc27["Questions"]["length"] > 0x5 &&
                (console["log"](
                    "\x1b[31m%s\x1b[0m",
                    "[WARNING]\x20TicketButton" +
                    _0x4ef60e +
                    "\x20has\x20more\x20than\x205\x20questions!\x20(Each\x20category\x20can\x20only\x20have\x20a\x20max\x20of\x205\x20questions,\x20due\x20to\x20a\x20Discord\x20limitation)"
                ),
                    _0x38de2c["push"](
                        "TicketButton" +
                        _0x4ef60e +
                        "\x20has\x20more\x20than\x205\x20questions!"
                    ));
        }
        if (_0x38de2c["length"] > 0x0) {
            let _0xdbab54 =
                "\x0a\x0a[" +
                new Date()["toLocaleString"]() +
                "]\x20[CONFIG\x20ERROR(S)]\x20\x0a" +
                _0x38de2c["join"]("\x0a\x20")["trim"]();
            fs["appendFile"]("./logs.txt", _0xdbab54, (_0x44c850) => {
                if (_0x44c850) console["log"](_0x44c850);
            });
        }
    }),
    (exports["saveTranscript"] = async function (_0xf68df4) {
        let _0x55fb08;
        if (_0xf68df4) {
            if (config["TicketTranscriptSettings"]["TranscriptType"] === "HTML") {
                _0x55fb08 = await discordTranscripts["createTranscript"](
                    _0xf68df4["channel"],
                    {
                        limit: -0x1,
                        minify: ![],
                        saveImages: config["TicketTranscriptSettings"]["SaveImages"],
                        returnType: "buffer",
                        poweredBy: ![],
                        fileName: _0xf68df4["channel"]["name"] + ".html",
                    }
                );
                if (config["TicketTranscriptSettings"]["SaveInFolder"])
                    fs["writeFileSync"](
                        "./transcripts/" +
                        _0xf68df4["channel"]["name"] +
                        "-transcript-" +
                        _0xf68df4["channel"]["id"] +
                        ".html",
                        _0x55fb08
                    );
                _0x55fb08 = new AttachmentBuilder(Buffer["from"](_0x55fb08), {
                    name: _0xf68df4["channel"]["name"] + "-transcript.html",
                });
            } else
                config["TicketTranscriptSettings"]["TranscriptType"] === "TXT" &&
                    (await _0xf68df4["channel"]["messages"]
                    ["fetch"]({ limit: 0x64 })
                    ["then"](async (_0x5a39df) => {
                        let _0x41441e = _0x5a39df["filter"](
                            (_0x66a7d2) => _0x66a7d2["author"]["bot"] !== !![]
                        )
                        ["map"](
                            (_0x2b987b) =>
                                new Date(_0x2b987b["createdTimestamp"])[
                                    "toLocaleString"
                                ]() +
                                "\x20-\x20" +
                                _0x2b987b["author"]["username"] +
                                "#" +
                                _0x2b987b["author"]["discriminator"] +
                                ":\x20" +
                                (_0x2b987b["attachments"]["size"] > 0x0
                                    ? _0x2b987b["attachments"]["first"]()["proxyURL"]
                                    : _0x2b987b["content"])
                        )
                        ["reverse"]()
                        ["join"]("\x0a");
                        if (_0x41441e["length"] < 0x1) _0x41441e = "Nothing";
                        if (config["TicketTranscriptSettings"]["SaveInFolder"])
                            fs["writeFileSync"](
                                "./transcripts/" +
                                _0xf68df4["channel"]["name"] +
                                "-transcript-" +
                                _0xf68df4["channel"]["id"] +
                                ".txt",
                                Buffer["from"](_0x41441e)
                            );
                        _0x55fb08 = new AttachmentBuilder(Buffer["from"](_0x41441e), {
                            name: _0xf68df4["channel"]["name"] + "-transcript.txt",
                        });
                    }));
        }
        return _0x55fb08;
    }),
    (exports["saveTranscriptAlertCmd"] = async function (_0x50662d) {
        if (_0x50662d) {
            if (config["TicketTranscriptSettings"]["TranscriptType"] === "HTML") {
                attachment = await discordTranscripts["createTranscript"](_0x50662d, {
                    limit: -0x1,
                    minify: ![],
                    saveImages: config["TicketTranscriptSettings"]["SaveImages"],
                    returnType: "buffer",
                    poweredBy: ![],
                    fileName: _0x50662d["name"] + ".html",
                });
                if (config["TicketTranscriptSettings"]["SaveInFolder"])
                    fs["writeFileSync"](
                        "./transcripts/" +
                        _0x50662d["name"] +
                        "-transcript-" +
                        _0x50662d["id"] +
                        ".html",
                        attachment
                    );
                attachment = new AttachmentBuilder(Buffer["from"](attachment), {
                    name: _0x50662d["name"] + "-transcript.html",
                });
            } else
                config["TicketTranscriptSettings"]["TranscriptType"] === "TXT" &&
                    (await _0x50662d["messages"]
                    ["fetch"]({ limit: 0x64 })
                    ["then"](async (_0x17b144) => {
                        let _0x262433 = _0x17b144["filter"](
                            (_0x3db714) => _0x3db714["author"]["bot"] !== !![]
                        )
                        ["map"](
                            (_0x56ae4e) =>
                                new Date(_0x56ae4e["createdTimestamp"])[
                                    "toLocaleString"
                                ]() +
                                "\x20-\x20" +
                                _0x56ae4e["author"]["username"] +
                                "#" +
                                _0x56ae4e["author"]["discriminator"] +
                                ":\x20" +
                                (_0x56ae4e["attachments"]["size"] > 0x0
                                    ? _0x56ae4e["attachments"]["first"]()["proxyURL"]
                                    : _0x56ae4e["content"])
                        )
                        ["reverse"]()
                        ["join"]("\x0a");
                        if (_0x262433["length"] < 0x1) _0x262433 = "Nothing";
                        if (config["TicketTranscriptSettings"]["SaveInFolder"])
                            fs["writeFileSync"](
                                "./transcripts/" +
                                _0x50662d["name"] +
                                "-transcript-" +
                                _0x50662d["id"] +
                                ".txt",
                                attachment
                            );
                        attachment = new AttachmentBuilder(Buffer["from"](_0x262433), {
                            name: _0x50662d["name"] + "-transcript.txt",
                        });
                    }));
        }
        return attachment;
    }),
    (exports["checkStripePayments"] = async function () {
        let _0x9af1de = client["guilds"]["cache"]["get"](config["GuildID"]);
        if (!client["stripeInvoices"]) return;
        const _0x5aca94 = client["stripeInvoices"]["filter"](
            (_0x4e2c5d) => _0x4e2c5d["status"] === "open"
        );
        if (!_0x5aca94) return;
        _0x5aca94["forEach"](async (_0x4413ba) => {
            let _0x2e88e5 = _0x9af1de["channels"]["cache"]["get"](
                _0x4413ba["channelID"]
            ),
                _0x2bf1d2 = _0x9af1de["members"]["cache"]["get"](_0x4413ba["userID"]),
                _0x4e35b9 = _0x9af1de["members"]["cache"]["get"](_0x4413ba["sellerID"]),
                _0x5677ac;
            if (_0x2bf1d2) {
                _0x5677ac = await client["stripe"]["invoices"]["retrieve"](
                    _0x4413ba["invoiceID"]
                );
                (!_0x5677ac || !_0x2e88e5) &&
                    client["stripeInvoices"]["delete"]("" + _0x4413ba["invoiceID"]);
                if (_0x5677ac["status"] === "paid")
                    await client["stripeInvoices"]["set"](
                        "" + _0x5677ac["id"],
                        "paid",
                        "status"
                    );
                await client["stripeInvoices"]["set"](
                    "" + _0x5677ac["id"],
                    "deleted",
                    "status"
                );
            }
            _0x2e88e5 &&
                _0x2bf1d2 &&
                client["stripeInvoices"]["get"]("" + _0x5677ac["id"], "status") ===
                "paid" &&
                (await _0x2e88e5["messages"]
                ["fetch"](_0x4413ba["messageID"])
                ["then"](async (_0xdd96dc) => {
                    const _0x257cba = new ActionRowBuilder()["addComponents"](
                        new ButtonBuilder()
                        ["setStyle"]("Link")
                        ["setURL"]("https://stripe.com")
                        ["setLabel"](config["Locale"]["PayPalPayInvoice"])
                        ["setDisabled"](!![])
                    ),
                        _0xe23a1 = _0xdd96dc["embeds"][0x0];
                    _0xe23a1["fields"][0x0] = {
                        name: "•\x20" + config["Locale"]["suggestionInformation"],
                        value:
                            ">\x20**" +
                            config["Locale"]["PayPalSeller"] +
                            "**\x20" +
                            _0x4e35b9 +
                            "\x0a>\x20**" +
                            config["Locale"]["PayPalUser"] +
                            "**\x20" +
                            _0x2bf1d2 +
                            "\x0a>\x20**" +
                            config["Locale"]["PayPalPrice"] +
                            "**\x20" +
                            config["StripeSettings"]["CurrencySymbol"] +
                            _0x4413ba["price"] +
                            "\x20(" +
                            config["StripeSettings"]["Currency"] +
                            ")\x0a>\x20**" +
                            config["Locale"]["suggestionStatus"] +
                            "**\x20🟢\x20PAID\x20(<t:" +
                            Math["round"](Date["now"]() / 0x3e8) +
                            ":R>)",
                    };
                    const _0xca4995 = EmbedBuilder["from"](_0xe23a1);
                    _0xca4995["setColor"]("Green"),
                        await _0xdd96dc["edit"]({
                            embeds: [_0xca4995],
                            components: [_0x257cba],
                        });
                }));
        });
    }),
    (exports["checkPayPalPayments"] = async function () {
        const _0x39f4cd = client["guilds"]["cache"]["get"](config["GuildID"]);
        if (!client["paypalInvoices"]) return;
        const _0x1effff = client["paypalInvoices"]["filter"](
            (_0x1a87b2) => _0x1a87b2["status"] === "DRAFT"
        );
        if (!_0x1effff) return;
        _0x1effff["forEach"]((_0x1cd7ac) => {
            const _0x42371c = _0x39f4cd["channels"]["cache"]["get"](
                _0x1cd7ac["channelID"]
            ),
                _0x8eee33 = _0x39f4cd["members"]["cache"]["get"](_0x1cd7ac["userID"]),
                _0x20a1e2 = _0x39f4cd["members"]["cache"]["get"](_0x1cd7ac["sellerID"]);
            _0x8eee33 &&
                client["paypal"]["invoice"]["get"](
                    _0x1cd7ac["invoiceID"],
                    function (_0xfe289f, _0x4bb73a) {
                        _0xfe289f
                            ? _0xfe289f["response"]["error"] === "invalid_client"
                                ? console["log"](
                                    "\x1b[31m%s\x1b[0m",
                                    "[ERROR]\x20The\x20PayPal\x20API\x20Credentials\x20you\x20specified\x20in\x20the\x20config\x20are\x20invalid!\x20Make\x20you\x20sure\x20you\x20use\x20the\x20\x22LIVE\x22\x20mode!"
                                )
                                : console["log"](_0xfe289f)
                            : ((!_0x42371c || !_0x4bb73a) &&
                                client["paypalInvoices"]["set"](
                                    "" + _0x4bb73a["id"],
                                    "deleted",
                                    "status"
                                ),
                                _0x4bb73a["status"] === "PAID" &&
                                client["paypalInvoices"]["set"](
                                    "" + _0x4bb73a["id"],
                                    "paid",
                                    "status"
                                ),
                                _0x4bb73a &&
                                _0x42371c &&
                                _0x8eee33 &&
                                client["paypalInvoices"]["get"](
                                    "" + _0x4bb73a["id"],
                                    "status"
                                ) === "paid" &&
                                _0x42371c["messages"]
                                ["fetch"](_0x1cd7ac["messageID"])
                                ["catch"]((_0x10e442) => { })
                                ["then"]((_0x35851d) => {
                                    const _0x8e2cb8 = new ActionRowBuilder()["addComponents"](
                                        new ButtonBuilder()
                                        ["setStyle"]("Link")
                                        ["setURL"]("https://paypal.com")
                                        ["setLabel"](config["Locale"]["PayPalPayInvoice"])
                                        ["setDisabled"](!![])
                                    ),
                                        _0xf9715c = _0x35851d["embeds"][0x0];
                                    _0xf9715c["fields"][0x0] = {
                                        name:
                                            "•\x20" + config["Locale"]["suggestionInformation"],
                                        value:
                                            ">\x20**" +
                                            config["Locale"]["PayPalSeller"] +
                                            "**\x20<@!" +
                                            _0x20a1e2["id"] +
                                            ">\x0a>\x20**" +
                                            config["Locale"]["PayPalUser"] +
                                            "**\x20<@!" +
                                            _0x8eee33["id"] +
                                            ">\x0a>\x20**" +
                                            config["Locale"]["PayPalPrice"] +
                                            "**\x20" +
                                            config["PayPalSettings"]["CurrencySymbol"] +
                                            _0x1cd7ac["price"] +
                                            "\x20(" +
                                            config["PayPalSettings"]["Currency"] +
                                            ")\x0a>\x20**" +
                                            config["Locale"]["suggestionStatus"] +
                                            "**\x20🟢\x20PAID\x20(<t:" +
                                            Math["round"](Date["now"]() / 0x3e8) +
                                            ":R>)",
                                    };
                                    const _0x3b6882 =
                                        EmbedBuilder["from"](_0xf9715c)["setColor"]("Green");
                                    _0x35851d["edit"]({
                                        embeds: [_0x3b6882],
                                        components: [_0x8e2cb8],
                                    });
                                }));
                    }
                );
        });
    }),
    (exports["checkIfUserHasSupportRoles"] = function (_0x354944, _0x1c3139) {
        let _0x484f23 = ![],
            _0x16d8e2 = _0x354944 || _0x1c3139;
        const _0x551140 = client["tickets"]["get"](
            "" + _0x16d8e2["channel"]["id"],
            "button"
        );
        for (let _0x5d914c = 0x1; _0x5d914c <= 0x8; _0x5d914c++) {
            const _0x2003db = config["TicketButton" + _0x5d914c];
            if (_0x551140 === "TicketButton" + _0x5d914c) {
                for (
                    let _0x17f80c = 0x0;
                    _0x17f80c < _0x2003db["SupportRoles"]["length"];
                    _0x17f80c++
                ) {
                    if (
                        _0x16d8e2["member"]["roles"]["cache"]["has"](
                            _0x2003db["SupportRoles"][_0x17f80c]
                        )
                    ) {
                        _0x484f23 = !![];
                        break;
                    }
                }
                break;
            }
        }
        return _0x484f23;
    }),
    client["login"](config["Token"])["catch"]((_0x2867ff) => {
        _0x2867ff["message"]["includes"](
            "An\x20invalid\x20token\x20was\x20provided"
        )
            ? (console["log"](
                "\x1b[31m%s\x1b[0m",
                "[ERROR]\x20The\x20bot\x20token\x20specified\x20in\x20the\x20config\x20is\x20incorrect!"
            ),
                process["exit"]())
            : (console["log"](
                "\x1b[31m%s\x1b[0m",
                "[ERROR]\x20An\x20error\x20occured\x20while\x20attempting\x20to\x20login\x20to\x20the\x20bot"
            ),
                console["log"](_0x2867ff),
                process["exit"]());
    });
